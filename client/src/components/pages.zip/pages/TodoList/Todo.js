import React from "react"
  import TodoList from "./TodoList"


  function Todo() {
      return (
          <div>
              <h1>Get sh*t done today!</h1>
              <TodoList />
          </div>
      )
  }

~ export default Todo