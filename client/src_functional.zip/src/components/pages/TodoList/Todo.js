import React from "react"
import TodoList from "./TodoList"


function Todo() {
    return (
        <div>
            <h1>Todo list</h1>
            <TodoList />
        </div>
    )
}

export default Todo 